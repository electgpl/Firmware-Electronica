#ifndef SW4
#define SW4 1
 
#banky
signed int16 sine_window[4] = {
12540,
30274,
30274,
12540
};

#endif
