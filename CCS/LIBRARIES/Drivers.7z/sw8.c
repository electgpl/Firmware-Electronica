#ifndef SW8
#define SW8 1
 
#banky
signed int16 sine_window[8] = {
6393 ,
18205,
27246,
32138,
32138,
27246,
18205,
6393
};

#endif
